// Explicit original 2010 word-copy tables; tools/extract_snapshot_maps.py.
export const SNAPSHOT_MAPS=Object.freeze({
  "save": {
    "routine": 4605344,
    "sourceSha256": "109293b2aeee72ed1b85a7ea8db810628606a4c646ef9e56191eea62a8774585",
    "arrays": [
      {
        "source": 5196404,
        "destination": 5384276,
        "stride": 4
      },
      {
        "source": 5385108,
        "destination": 5386836,
        "stride": 4
      },
      {
        "source": 5227348,
        "destination": 5237060,
        "stride": 4
      },
      {
        "source": 5197180,
        "destination": 5213100,
        "stride": 4
      },
      {
        "source": 5223300,
        "destination": 5462996,
        "stride": 4
      },
      {
        "source": 5221988,
        "destination": 5462308,
        "stride": 4
      },
      {
        "source": 5322004,
        "destination": 5459468,
        "stride": 4
      },
      {
        "source": 5321860,
        "destination": 5459324,
        "stride": 4
      },
      {
        "source": 5235380,
        "destination": 5194724,
        "stride": 4
      },
      {
        "source": 5210884,
        "destination": 5460612,
        "stride": 4
      },
      {
        "source": 5221844,
        "destination": 5318420,
        "stride": 4
      },
      {
        "source": 5222132,
        "destination": 5193916,
        "stride": 4
      },
      {
        "source": 5195060,
        "destination": 5234852,
        "stride": 4
      },
      {
        "source": 5236436,
        "destination": 5194076,
        "stride": 4
      },
      {
        "source": 5385836,
        "destination": 5461196,
        "stride": 4
      },
      {
        "source": 5194580,
        "destination": 5213252,
        "stride": 4
      },
      {
        "source": 5237204,
        "destination": 5386684,
        "stride": 4
      },
      {
        "source": 5460188,
        "destination": 5387684,
        "stride": 4
      },
      {
        "source": 5211452,
        "destination": 5460948,
        "stride": 4
      },
      {
        "source": 5461828,
        "destination": 5396956,
        "stride": 4
      },
      {
        "source": 5234668,
        "destination": 5193724,
        "stride": 4
      },
      {
        "source": 5386228,
        "destination": 5313940,
        "stride": 4
      },
      {
        "source": 5205016,
        "destination": 5389368,
        "stride": 8
      },
      {
        "source": 5204736,
        "destination": 5389088,
        "stride": 8
      },
      {
        "source": 5235080,
        "destination": 5223024,
        "stride": 8
      }
    ],
    "scalars": [
      {
        "source": 5213392,
        "destination": 5204404
      },
      {
        "source": 5224888,
        "destination": 5464784
      },
      {
        "source": 5205344,
        "destination": 5193904
      },
      {
        "source": 5459932,
        "destination": 5195632
      },
      {
        "source": 5465256,
        "destination": 5386448
      },
      {
        "source": 5226832,
        "destination": 5193448
      },
      {
        "source": 5226836,
        "destination": 5193452
      },
      {
        "source": 5459304,
        "destination": 5386976
      },
      {
        "source": 5459308,
        "destination": 5386980
      },
      {
        "source": 5461496,
        "destination": 5389056
      },
      {
        "source": 5461500,
        "destination": 5389060
      },
      {
        "source": 5385664,
        "destination": 5397128
      },
      {
        "source": 5385668,
        "destination": 5397132
      },
      {
        "source": 5237048,
        "destination": 5384920
      },
      {
        "source": 5237052,
        "destination": 5384924
      },
      {
        "source": 5314084,
        "destination": 5235028
      },
      {
        "source": 5314088,
        "destination": 5235032
      },
      {
        "source": 5206164,
        "destination": 5461524
      },
      {
        "source": 5206168,
        "destination": 5461528
      },
      {
        "source": 5204588,
        "destination": 5461164
      },
      {
        "source": 5204592,
        "destination": 5461168
      },
      {
        "source": 5225388,
        "destination": 5213084
      },
      {
        "source": 5225392,
        "destination": 5213088
      },
      {
        "source": 5461684,
        "destination": 5205532
      },
      {
        "source": 5461688,
        "destination": 5205536
      },
      {
        "source": 5195040,
        "destination": 5461972
      },
      {
        "source": 5195044,
        "destination": 5462000
      },
      {
        "source": 5087696,
        "destination": 5205520
      },
      {
        "source": 5087700,
        "destination": 5464792
      },
      {
        "source": 5459620,
        "destination": 5386632
      },
      {
        "source": 5236584,
        "destination": 5386452
      },
      {
        "source": 5205292,
        "destination": 5225344
      },
      {
        "source": 5459604,
        "destination": 5462456
      },
      {
        "source": 5226260,
        "destination": 5385092
      },
      {
        "source": 5226264,
        "destination": 5385096
      },
      {
        "source": 5386424,
        "destination": 5237344
      },
      {
        "source": 5087692,
        "destination": 5387848
      },
      {
        "source": 5460180,
        "destination": 5397100
      },
      {
        "source": 5397092,
        "destination": 5223444
      },
      {
        "source": 5462512,
        "destination": 5397168
      },
      {
        "source": 5462516,
        "destination": 5397172
      }
    ]
  },
  "restore": {
    "routine": 4604288,
    "sourceSha256": "d111090c053d64f2506f8e06b83478f91e48d1448f73cab763663b77f20bda60",
    "arrays": [
      {
        "source": 5384276,
        "destination": 5196404,
        "stride": 4
      },
      {
        "source": 5386836,
        "destination": 5385108,
        "stride": 4
      },
      {
        "source": 5237060,
        "destination": 5227348,
        "stride": 4
      },
      {
        "source": 5213100,
        "destination": 5197180,
        "stride": 4
      },
      {
        "source": 5462996,
        "destination": 5223300,
        "stride": 4
      },
      {
        "source": 5462308,
        "destination": 5221988,
        "stride": 4
      },
      {
        "source": 5459468,
        "destination": 5322004,
        "stride": 4
      },
      {
        "source": 5459324,
        "destination": 5321860,
        "stride": 4
      },
      {
        "source": 5194724,
        "destination": 5235380,
        "stride": 4
      },
      {
        "source": 5460612,
        "destination": 5210884,
        "stride": 4
      },
      {
        "source": 5318420,
        "destination": 5221844,
        "stride": 4
      },
      {
        "source": 5193916,
        "destination": 5222132,
        "stride": 4
      },
      {
        "source": 5234852,
        "destination": 5195060,
        "stride": 4
      },
      {
        "source": 5194076,
        "destination": 5236436,
        "stride": 4
      },
      {
        "source": 5461196,
        "destination": 5385836,
        "stride": 4
      },
      {
        "source": 5213252,
        "destination": 5194580,
        "stride": 4
      },
      {
        "source": 5386684,
        "destination": 5237204,
        "stride": 4
      },
      {
        "source": 5387684,
        "destination": 5460188,
        "stride": 4
      },
      {
        "source": 5460948,
        "destination": 5211452,
        "stride": 4
      },
      {
        "source": 5396956,
        "destination": 5461828,
        "stride": 4
      },
      {
        "source": 5193724,
        "destination": 5234668,
        "stride": 4
      },
      {
        "source": 5313940,
        "destination": 5386228,
        "stride": 4
      },
      {
        "source": 5389368,
        "destination": 5205016,
        "stride": 8
      },
      {
        "source": 5389088,
        "destination": 5204736,
        "stride": 8
      },
      {
        "source": 5223024,
        "destination": 5235080,
        "stride": 8
      }
    ],
    "scalars": [
      {
        "source": 5204404,
        "destination": 5213392
      },
      {
        "source": 5464784,
        "destination": 5224888
      },
      {
        "source": 5195632,
        "destination": 5459932
      },
      {
        "source": 5386448,
        "destination": 5465256
      },
      {
        "source": 5193452,
        "destination": 5226836
      },
      {
        "source": 5386976,
        "destination": 5459304
      },
      {
        "source": 5389056,
        "destination": 5461496
      },
      {
        "source": 5389060,
        "destination": 5461500
      },
      {
        "source": 5397132,
        "destination": 5385668
      },
      {
        "source": 5384920,
        "destination": 5237048
      },
      {
        "source": 5235028,
        "destination": 5314084
      },
      {
        "source": 5193904,
        "destination": 5205344
      },
      {
        "source": 5235032,
        "destination": 5314088
      },
      {
        "source": 5461528,
        "destination": 5206168
      },
      {
        "source": 5193448,
        "destination": 5226832
      },
      {
        "source": 5461164,
        "destination": 5204588
      },
      {
        "source": 5213084,
        "destination": 5225388
      },
      {
        "source": 5386980,
        "destination": 5459308
      },
      {
        "source": 5213088,
        "destination": 5225392
      },
      {
        "source": 5205536,
        "destination": 5461688
      },
      {
        "source": 5397128,
        "destination": 5385664
      },
      {
        "source": 5461972,
        "destination": 5195040
      },
      {
        "source": 5205520,
        "destination": 5087696
      },
      {
        "source": 5384924,
        "destination": 5237052
      },
      {
        "source": 5464792,
        "destination": 5087700
      },
      {
        "source": 5386632,
        "destination": 5459620
      },
      {
        "source": 5461524,
        "destination": 5206164
      },
      {
        "source": 5386452,
        "destination": 5236584
      },
      {
        "source": 5225344,
        "destination": 5205292
      },
      {
        "source": 5461168,
        "destination": 5204592
      },
      {
        "source": 5462456,
        "destination": 5459604
      },
      {
        "source": 5385092,
        "destination": 5226260
      },
      {
        "source": 5205532,
        "destination": 5461684
      },
      {
        "source": 5385096,
        "destination": 5226264
      },
      {
        "source": 5237344,
        "destination": 5386424
      },
      {
        "source": 5462000,
        "destination": 5195044
      },
      {
        "source": 5397100,
        "destination": 5460180
      },
      {
        "source": 5223444,
        "destination": 5397092
      },
      {
        "source": 5397168,
        "destination": 5462512
      },
      {
        "source": 5397172,
        "destination": 5462516
      },
      {
        "source": 5397168,
        "destination": 5464624
      },
      {
        "source": 5397172,
        "destination": 5464628
      }
    ]
  }
});
